# -*- coding: utf-8 -*-
# Copyright (c) 2026 Einstein-Project
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, version 3.
# by Klaus Reitbauer & google-gemini

Alle Erkenntnisse und auch Code wurden durch eine Zusammenarbeit von Klaus Reitbauer und Google-Gemini ausgearbeit.
Da ich (Klaus Reitbauer) kein Programmierer bin musste ich diese Hilfe in Anspruch nehmen. Die Logik wurde stets von mir geprüft.
Da ich auch keine tiefergehenden Drehstromelektrischen Kenntnisse habe bleiben letzte Unsicherheiten bestehen. 
Die Phasenwinkelangaben bilden sich aus dem Winkelversatz von Strom und Spannung. (voreilend, nacheilend) und nicht aus dem 120°
Versatz der Phasenspannungen! 
Der hoymiles-Chint DTSU666Ct ist ein 4 quadrantenzähler. hoymiles fordert die Ct-Klemmen richtung Netz zeigen zu lassen!
Wir haben versucht das in unserem Code per Software richtung Haus/Verbraucher/Erzeuger umzudrehen. 
Kein Gewähr auf absolute Korrektheit! Verwendung stets auf eigene Gefahr! Prüfe selbst wer sich daran bindet!

===============================================================================
🎯 CHINT DTSU666 EMULATOR – WICHTIGE HARDWARE- & TIMING-DOKUMENTATION
===============================================================================
Letzter Stand: Oktober 2026
Hier besteht nur eine direkte Verbindung vom FTDI-Kabel zum Chint-Zähler.
Das schließt in unserem Fall eine weiterverwendung der originalen hoymiles-DTU Pro aus!!!
Wir sniffen nicht nur sondern senden aktiv Anfragen zum Auslesen als ModbusRTU-Master!
Für mich war die hoymiles DTU Pro ein Katastrophengerät das ich nun entfernt habe. 

1. DAS HAUPTPROBLEM (WARUM ES ANFANGS NUR TIMEOUTS GAB)
-------------------------------------------------------------------------------
Das Venus OS besitzt einen automatischen Hintergrund-Scanner namens 
'vedirect-dbus'. Dieser sucht permanent auf allen USB-Schnittstellen nach 
Victron-Geräten (MPPTs, Shunts). 

Jedes Mal, wenn unser Emulator lief, hat dieser Victron-Dienst asynchron 
dazwischengegrätscht und uns die Byte-Pakete auf Kernel-Ebene vor der Nase 
weggestohlen. Das führte zu dem unlesbaren "0 Bytes Dauer-Timeout" im Log!

2. DIE UNZERSTÖRBARE LÖSUNG (UDEV-SPERRE)
-------------------------------------------------------------------------------
Um den Victron-Scanner dauerhaft und UPDATESICHER von unserem FTDI-Kabel 
auszusperren, wurde eine udev-Regel angelegt:

Pfad: /data/conf/udev/rules.d/99-chint-override.rules

Inhalt der Regel:
SUBSYSTEM=="tty", ATTRS{idVendor}=="0403", ATTRS{idProduct}=="6001", ATTRS{serial}=="BG03M1GA", ENV{VE_IGNORE}="1"

Bedeutung:
Der Ordner '/data/' wird bei Victron-Firmware-Updates NIEMALS überschrieben. 
Das 'ENV{VE_IGNORE}="1"' zwingt das System, dieses Kabel für interne Scanner 
vollständig unsichtbar zu machen. Das Kabel gehört dem Emulator exklusiv.

3. FORENSISCHE DIAGNOSE-BEFEHLE FÜR DIE KONSOLE
-------------------------------------------------------------------------------
Falls es in Zukunft jemals wieder zu Timeouts kommen sollte, prüfe die Leitung 
mit diesem Befehl (BusyBox fuser):

    fuser /dev/serial/by-id/usb-FTDI_FT232R_USB_UART_BG03M1GA-if00-port0

• Bleibt die Ausgabe LEER -> Alles perfekt. Die Leitung ist frei.
• Taucht eine PID (Zahl) auf -> Ein fremder Prozess blockiert das Kabel!

Den Blockierer wirfst du mit diesem Befehl hart aus dem RAM:

    fuser -k /dev/serial/by-id/usb-FTDI_FT232R_USB_UART_BG03M1GA-if00-port0

4. PROTOKOLL-ERKENNTNISSE (FÜR DIE MATHEMATIK IM VORDERGRUND)
-------------------------------------------------------------------------------
• Slave-ID des Hoymiles-Chints: 184 (Hex: 0xB8)
• Erlaubter Funktionscode: 0x03 (Holding Registers) – NICHT 0x04!
• Daten-Format: Reines IEEE 754 Big-Endian Float (ABCD)
• Die Register-Matrix liefert im 2000er Block skalisierte Werte (Faktor 10 
  bzw. verkettete Spannungen), die im d-Bus-Vordergrund passend dividiert 
  werden müssen, um echte 230V anzuzeigen.
der 4000er Block liefert Energiewerte. Welche genau steht in der setup_tools/MODBUS_MATRIX.md
===============================================================================
