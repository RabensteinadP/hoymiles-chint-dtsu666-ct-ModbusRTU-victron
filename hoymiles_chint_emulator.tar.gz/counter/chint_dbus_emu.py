#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ===============================================================================
# Copyright (c) 2026 Einstein-Project
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, version 3.
# ===============================================================================
# 🎯 URHEBER-HINWEIS & PROJEKT-HISTORIE:
# Alle Erkenntnisse und auch der Code wurden durch eine enge Zusammenarbeit von
# Klaus Reitbauer und Google-Gemini ausgearbeitet. 
# Da ich (Klaus Reitbauer) kein Programmierer bin, habe ich diese Hilfe in Anspruch
# genommen. Die Logik wurde stets von mir geprüft.
#
# ⚠️ ELEKTRISCHER HAFTUNGSAUSSCHLUSS & GEWÄHRLEISTUNG:
# Da ich keine tiefergehenden drehstrom-elektrotechnischen Kenntnisse habe, bleiben
# letzte Unsicherheiten bestehen. 
# • Die Phasenwinkelangaben bilden sich aus dem reinen Winkelversatz von Strom und
#   Spannung (voreilend/nacheilend) und NICHT aus dem 120°-Versatz der Phasenspannungen!
# • Der Hoymiles-Chint DTSU666-CT ist ein 4-Quadranten-Zähler. Hoymiles fordert, 
#   dass die CT-Klemmen Richtung Netz zeigen. Wir haben versucht, das im Code
#   per Software in Richtung Haus/Verbraucher/Erzeuger umzudrehen.
#
# KEIN GEWÄHR AUF ABSOLUTE KORREKTHEIT! VERWENDUNG STETS AUF EIGENE GEFAHR!
# PRÜFE SELBST, WER SICH DARAN BINDET!
# ===============================================================================

import sys
import os
import glob
import serial
import time
import struct
import configparser
import subprocess
from gi.repository import GLib

# 1. Zentrale pfade.ini einlesen (Vollständig dynamisch über dein Framework)
MASTER_PFADE_INI = '/data/etc/victron-device-emulators/config/pfade.ini'
master_config = configparser.ConfigParser()
master_config.optionxform = str
if not master_config.read(MASTER_PFADE_INI):
    print(f"❌ Master-Pfade '{MASTER_PFADE_INI}' nicht lesbar!", file=sys.stderr)
    sys.exit(1)

# Direktes Auslesen der registrierten Projektpfade aus der korrekten Framework-Sektion
INI_PFAD = master_config['CHINT_EMULATOR_PATHS']['counter_ini_path']

# 2. Lokale counter.ini einlesen (Schnittstellen-Daten holen)
config = configparser.ConfigParser()
config.optionxform = str
if not config.read(INI_PFAD):
    print(f"❌ Emulator-Konfiguration '{INI_PFAD}' nicht lesbar!", file=sys.stderr)
    sys.exit(1)

PORT = config['Schnittstelle']['hardware_id']
BAUD = int(config['Schnittstelle']['baudrate'])
CHINT_ID = int(config['Schnittstelle']['chint_hardware_slave_id'])
KABEL_SERIAL = config['Schnittstelle'].get('kabel_serial', 'UNBEKANNT')

# 4. Dynamischer eiserner Hardware-Schutzschild (Fehlerbereinigt ohne 'Mecca')
if KABEL_SERIAL != 'UNBEKANNT':
    try:
        UDEV_RULE = f'''# 1. FTDI-Wandler komplett fuer alle Victron-Scans unsichtbar machen (Harte Ignorierung)
SUBSYSTEM=="tty", ATTRS{{idVendor}}=="0403", ATTRS{{idProduct}}=="6001", ATTRS{{serial}}=="{KABEL_SERIAL}", ENV{{VE_IGNORE}}="1", ENV{{ID_MM_DEVICE_IGNORE}}="1", ENV{{ID_RESERVED_FROM_AUT>
# 2. Dem Kernel befehlen, die Zugriffsrechte so zu setzen, dass NUR dein Skript die Hand drauf hat
SUBSYSTEM=="tty", ATTRS{{idVendor}}=="0403", ATTRS{{idProduct}}=="6001", ATTRS{{serial}}=="{KABEL_SERIAL}", OWNER="root", GROUP="root", MODE="0600"
'''
        os.makedirs("/data/conf/udev/rules.d", exist_ok=True)
        with open("/data/conf/udev/rules.d/99-chint-override.rules", "w") as uf:
            uf.write(UDEV_RULE)
        subprocess.run(["udevadm", "control", "--reload-rules"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        subprocess.run(["udevadm", "trigger"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(0.1)
    except:
        pass


# 3. Sofortiger doppelter Failsafe-Stoßtritt zur Befreiung der Schnittstelle (Live-Erkenntnis)
try:
    subprocess.run(["fuser", "-k", PORT], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(0.2)
    subprocess.run(["fuser", "-k", PORT], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(0.2)
except:
    pass


VIC_ID = int(config['VictronDevice']['emulierte_victron_slave_id'])
NAME = config['VictronDevice']['custom_name']
INSTANCE = int(config['VictronDevice']['device_instance'])
ROLE = config['VictronDevice']['role']
POSITION = int(config['VictronDevice'].get('position', '0'))
MAX_POWER = int(config['VictronDevice'].get('max_power_w', '24000'))
MAX_CURRENT = float(config['VictronDevice'].get('max_current_a', '32.0'))

sys.path.insert(1, os.path.join(os.path.dirname(__file__), '/opt/victronenergy/dbus-systemcalc-py/ext/velib_python'))
from vedbus import VeDbusService
from dbus.mainloop.glib import DBusGMainLoop
DBusGMainLoop(set_as_default=True)

INV_W = config['Hardware_Invertierung_Kaskade'].getboolean('global_klemmen_spiegelung_hoymiles_180_grad')
TAUSCH_E = config['Hardware_Invertierung_Kaskade'].getboolean('override_tausche_energie_import_export')
TAUSCH_P_E = config['Hardware_Invertierung_Kaskade'].getboolean('override_tausche_phasen_energie_import_export')
INV_P = config['Hardware_Invertierung_Kaskade'].getboolean('override_wirkleistung_w_invertieren')
INV_Q = config['Hardware_Invertierung_Kaskade'].getboolean('override_blindleistung_var_invertieren')
INV_PF = config['Hardware_Invertierung_Kaskade'].getboolean('override_powerfaktor_pf_invertieren')
SPIEGEL_ANG = config['Hardware_Invertierung_Kaskade'].getboolean('override_phasenwinkel_grad_spiegeln')

ALARM_DREH = config['Netz_Ueberwachung_Alarme'].getboolean('ueberwache_drehfeld_richtung')
MIN_U = float(config['Netz_Ueberwachung_Alarme']['min_spannung_alarm'])
MAX_U = float(config['Netz_Ueberwachung_Alarme']['max_spannung_alarm'])
POLL_E_S = int(config['Intervalle_Taktung']['energy_polling_s'])

# --- REINE ABSTURZSICHERE TRANSFORMATION DER INI-FALLBACKS ---
WATCH_TIMEOUT_S = float(config['Intervalle_Taktung'].get('freeze_watchdog_s', '6'))
def parse_fb(v_str, d):
    if v_str is None or str(v_str).strip().lower() == 'none': return None
    try: return int(v_str)
    except: return d
FB_TOT = parse_fb(config['Intervalle_Taktung'].get('fallback_power_total'), -3000)
FB_L1  = parse_fb(config['Intervalle_Taktung'].get('fallback_power_l1'), -1000)
FB_L2  = parse_fb(config['Intervalle_Taktung'].get('fallback_power_l2'), -1000)
FB_L3  = parse_fb(config['Intervalle_Taktung'].get('fallback_power_l3'), -1000)
p_tot = FB_TOT
p_l1  = FB_L1
p_l2  = FB_L2
p_l3  = FB_L3

BYTES_BLOCK1 = 129
BYTES_BLOCK2 = 81
letzte_e_zeit = 0.0
letzter_erfolgs_ts = 0.0  # 0.0 erzwingt sauberes Abwarten des allerersten Modbus-Pakets beim Booten!

def berechne_crc16(data):
    crc = 0xFFFF
    for pos in data:
        crc ^= pos
        for _ in range(8):
            if (crc & 1) != 0: crc >>= 1; crc ^= 0xA001
            else: crc >>= 1
    return crc

def update_ini(key, value):
    config.set('VictronDevice', key, str(value))
    with open(INI_PFAD, 'w') as f: config.write(f)

def callback_dbus_write(path, value):
    global VIC_ID, NAME, INSTANCE, ROLE, POSITION, MAX_POWER, MAX_CURRENT
    if path == '/Storage/UnitId': update_ini('emulierte_victron_slave_id', value); VIC_ID = int(value)
    elif path == '/CustomName': update_ini('custom_name', value); NAME = str(value)
    elif path == '/DeviceInstance': update_ini('device_instance', value); INSTANCE = int(value)
    elif path == '/Role': update_ini('role', value); ROLE = str(value)
    elif path == '/Position': update_ini('position', value); POSITION = int(value)
    elif path == '/Ac/MaxPower': update_ini('max_power_w', value); MAX_POWER = int(value)
    elif path == '/MaxCurrent': update_ini('max_current_a', value); MAX_CURRENT = float(value)
    return True

dbus = VeDbusService(f'com.victronenergy.{ROLE}.gw{INSTANCE}', register=False)
dbus.onchange = callback_dbus_write

dbus.add_path('/Mgmt/ProcessName', 'chint_dbus_emu.py')
dbus.add_path('/Mgmt/ProcessVersion', config['VictronDevice']['firmware_version'])
dbus.add_path('/Mgmt/Connection', config['VictronDevice']['connection_string'])
dbus.add_path('/DeviceInstance', INSTANCE, writeable=True)
dbus.add_path('/CustomName', NAME, writeable=True)
dbus.add_path('/Role', ROLE, writeable=True)
dbus.add_path('/Position', POSITION, writeable=True)
dbus.add_path('/Storage/UnitId', VIC_ID, writeable=True)
dbus.add_path('/ProductId', int(config['VictronDevice']['product_id']))
dbus.add_path('/ProductName', config['VictronDevice']['product_name'])
dbus.add_path('/FirmwareVersion', float(config['VictronDevice']['firmware_version']))
dbus.add_path('/HardwareVersion', float(config['VictronDevice']['hardware_version']))
dbus.add_path('/Connected', 0)
dbus.add_path('/ErrorCode', 0)

cf_w = lambda p, v: "{:.0f}W".format(v) if v is not None else "--"
cf_v = lambda p, v: "{:.1f}V".format(v) if v is not None else "--"
cf_a = lambda p, v: "{:.3f}A".format(v) if v is not None else "--"
cf_k = lambda p, v: "{:.2f}kWh".format(v) if v is not None else "--"
cf_va = lambda p, v: "{:.0f}VA".format(v) if v is not None else "--"
cf_var = lambda p, v: "{:.0f}var".format(v) if v is not None else "--"
cf_kvarh = lambda p, v: "{:.2f}kvarh".format(v) if v is not None else None

dbus.add_path('/Ac/Energy/Reactive/Forward', 0.0, gettextcallback=cf_kvarh)
dbus.add_path('/Ac/Energy/Reactive/Reverse', 0.0, gettextcallback=cf_kvarh)

dbus.add_path('/Ac/Voltage', 0.0, gettextcallback=cf_v)
dbus.add_path('/Ac/Power', 0, gettextcallback=cf_w)
dbus.add_path('/Ac/Current', 0.0, gettextcallback=cf_a)
dbus.add_path('/Ac/MaxPower', MAX_POWER, writeable=True, gettextcallback=cf_w)
dbus.add_path('/Ac/ApparentPower', 0, gettextcallback=cf_va)
dbus.add_path('/Ac/ReactivePower', 0, gettextcallback=cf_var)
dbus.add_path('/Ac/PowerFactor', 0.0, gettextcallback=lambda p, v: "{:.3f}".format(v) if v is not None else "--")
dbus.add_path('/Ac/Energy/Forward', 0.0, gettextcallback=cf_k)
dbus.add_path('/Ac/Energy/Reverse', 0.0, gettextcallback=cf_k)
dbus.add_path('/Ac/LineToLine/L1ToL2', 0.0, gettextcallback=cf_v)
dbus.add_path('/Ac/LineToLine/L2ToL3', 0.0, gettextcallback=cf_v)
dbus.add_path('/Ac/LineToLine/L3ToL1', 0.0, gettextcallback=cf_v)

for ph in ['L1', 'L2', 'L3']:
    dbus.add_path(f'/Ac/{ph}/Voltage', 0.0, gettextcallback=cf_v)
    dbus.add_path(f'/Ac/{ph}/Current', 0.0, gettextcallback=cf_a)
    dbus.add_path(f'/Ac/{ph}/Power', 0, gettextcallback=cf_w)
    dbus.add_path(f'/Ac/{ph}/ReactivePower', 0, gettextcallback=cf_var)
    dbus.add_path(f'/Ac/{ph}/ApparentPower', 0, gettextcallback=cf_va)
    dbus.add_path(f'/Ac/{ph}/PowerFactor', 0.0, gettextcallback=lambda p, v: "{:.3f}".format(v) if v is not None else "--")
    dbus.add_path(f'/Ac/{ph}/Energy/Forward', 0.0, gettextcallback=cf_k)
    dbus.add_path(f'/Ac/{ph}/Energy/Reverse', 0.0, gettextcallback=cf_k)
    dbus.add_path(f'/Ac/{ph}/PhaseAngle', 0.0, gettextcallback=lambda p, v: "{:.1f}°".format(v) if v is not None else "--")

dbus.add_path('/MaxCurrent', MAX_CURRENT, writeable=True, gettextcallback=cf_a)
dbus.register()

try:
    dev_name = os.path.basename(PORT)
    for path in glob.glob(f"/sys/bus/usb-serial/devices/*/latency_timer") + glob.glob(f"/sys/class/tty/{dev_name}/device/latency_timer"):
        with open(path, "w") as f: f.write("1")
except: pass

ser = serial.Serial(port=PORT, baudrate=BAUD, timeout=0.15)
req_1 = bytearray([CHINT_ID, 0x03, 0x20, 0x00, 0x00, 0x3E])
req_1.extend(berechne_crc16(req_1).to_bytes(2, byteorder='little'))
req_2 = bytearray([CHINT_ID, 0x03, 0x40, 0x00, 0x00, 0x26])
req_2.extend(berechne_crc16(req_2).to_bytes(2, byteorder='little'))

local_p2 = bytearray()
def dbus_vordergrund_schleife():
    global letzte_e_zeit, local_p2, letzter_erfolgs_ts
    ts = time.strftime('%H:%M:%S')
    local_p1 = bytearray()
    # 🎯 Unzerstörbare Kaltstart-Definition direkt aus deiner INI
    p_tot, p_l1, p_l2, p_l3 = FB_TOT, FB_L1, FB_L2, FB_L3
    u_durchschnitt, i_summe = None, None
    u_l12, u_l23, u_l31 = None, None, None
    u_l1, u_l2, u_l3 = None, None, None
    i_l1, i_l2, i_l3 = None, None, None
    q_tot, q_l1, q_l2, q_l3 = 0, 0, 0, 0
    s_tot, s_l1, s_l2, s_l3 = 0, 0, 0, 0
    pf_tot, pf_l1, pf_l2, pf_l3 = 0, 0, 0, 0
    ang_l1, ang_l2, ang_l3 = 0, 0, 0
    err_code = 4 if (time.time() - letzter_erfolgs_ts) > WATCH_TIMEOUT_S else 0

    # 🎯 OPENDTU-ZWANGBREMSEN-VORAB-CHECK (Ueberschreibt d-Bus bei Freeze, blockiert aber NICHT den Modbus-Sende-Takt!)
    if letzter_erfolgs_ts > 0.0 and (time.time() - letzter_erfolgs_ts) > WATCH_TIMEOUT_S:
        print(f"[{ts}] 🚨 FREEZE ALARM! Modbus steht starr. Sende Inverter-Bremse: {FB_TOT}W.")
        dbus['/Connected'] = 1
        dbus['/ErrorCode'] = err_code
        dbus['/Ac/Voltage'] = round(u_durchschnitt, 1) if u_durchschnitt is not None else None
        dbus['/Ac/Power'] = int(p_tot) if p_tot is not None else None
        dbus['/Ac/Current'] = round(i_summe, 3) if i_summe is not None else None
        dbus['/Ac/ReactivePower'] = None; dbus['/Ac/PowerFactor'] = None
        dbus['/Ac/L1/Power'] = FB_L1; dbus['/Ac/L2/Power'] = FB_L2; dbus['/Ac/L3/Power'] = FB_L3
        for p in ['L1', 'L2', 'L3']:
            dbus[f'/Ac/{p}/Voltage'] = None; dbus[f'/Ac/{p}/Current'] = None
            dbus[f'/Ac/{p}/ReactivePower'] = None; dbus[f'/Ac/{p}/ApparentPower'] = None
            dbus[f'/Ac/{p}/PowerFactor'] = None; dbus[f'/Ac/{p}/PhaseAngle'] = None
        try:
            ser.close()
            ser.open()
        except: pass

    try:
        ser.reset_input_buffer()
        ser.write(req_1); ser.flush()
        res1 = ser.read(BYTES_BLOCK1)
        if len(res1) == BYTES_BLOCK1 and res1[0] == CHINT_ID and res1[1] == 0x03:
            if berechne_crc16(res1) == 0:
                local_p1[:] = res1[3:127]
                print(f"[{ts}] 🟢 Modbus: Block 1 fehlerfrei empfangen.")
                letzter_erfolgs_ts = time.time()
        jetzt = time.time()
        if len(local_p1) >= 124 and (letzte_e_zeit == 0.0 or (jetzt - letzte_e_zeit >= float(POLL_E_S))):
            time.sleep(0.01)
            ser.write(req_2); ser.flush()
            res2 = ser.read(BYTES_BLOCK2)
            if len(res2) == BYTES_BLOCK2 and res2[0] == CHINT_ID and res2[1] == 0x03:
                if berechne_crc16(res2) == 0:
                    local_p2[:] = res2[3:79]
                    letzte_e_zeit = jetzt
                    print(f"[{ts}] 🔋 Modbus: Erstabfrage/Intervall Block 2 fehlerfrei empfangen.")
    except Exception as e:
        print(f"[{ts}] ⚠️ Bus-Timeout oder Stoerung: {e}")
        return True

    if len(local_p1) >= 124:
        v1 = []
        for r in range(0, 124, 4): v1.append(struct.unpack('>f', local_p1[r:r+4])[0])
        v2 = []
        if len(local_p2) >= 76:
            for r in range(0, 76, 4): v2.append(struct.unpack('>f', local_p2[r:r+4])[0])

        u_l12, u_l23, u_l31 = float(v1[0]), float(v1[1]), float(v1[2])
        u_l1, u_l2, u_l3 = float(v1[3]), float(v1[4]), float(v1[5])
        i_l1, i_l2, i_l3 = float(v1[6]), float(v1[7]), float(v1[8])

        w_factor = -1.0 if (INV_W or INV_P) else 1.0
        p_tot = (float(v1[9]) / 10.0) * w_factor
        p_l1  = (float(v1[10]) / 10.0) * w_factor
        p_l2  = (float(v1[11]) / 10.0) * w_factor
        p_l3  = (float(v1[12]) / 10.0) * w_factor
#        p_tot = p_l1 + p_l2 + p_l3

        var_factor = -1.0 if (INV_W or INV_Q) else 1.0
        q_tot = (float(v1[13]) / 10.0) * var_factor
        q_l1  = (float(v1[14]) / 10.0) * var_factor
        q_l2  = (float(v1[15]) / 10.0) * var_factor
        q_l3  = (float(v1[16]) / 10.0) * var_factor
#        q_tot = q_l1 + q_l2 + q_l3

        s_l1, s_l2, s_l3 = float(v1[18]) / 10.0, float(v1[19]) / 10.0, float(v1[20]) / 10.0
        s_tot = float(v1[17]) / 10.0
        pf_factor = -1.0 if (INV_W or INV_PF) else 1.0
        pf_tot = (float(v1[21]) / 1000.0) * pf_factor
        pf_l1  = (float(v1[22]) / 1000.0) * pf_factor
        pf_l2  = (float(v1[23]) / 1000.0) * pf_factor
        pf_l3  = (float(v1[24]) / 1000.0) * pf_factor
        shift_ang = 180.0 if (INV_W or SPIEGEL_ANG) else 0.0
        ang_l1 = (float(v1[25]) / 10.0 + shift_ang) % 360.0
        ang_l2 = (float(v1[26]) / 10.0 + shift_ang) % 360.0
        ang_l3 = (float(v1[27]) / 10.0 + shift_ang) % 360.0

        err_code = 0
        if ALARM_DREH and int(v1[9]) == 1: err_code = 1
        elif u_l1/10.0 < 10.0 or u_l2/10.0 < 10.0 or u_l3/10.0 < 10.0: err_code = 4
        elif u_l1/10.0 < MIN_U or u_l2/10.0 < MIN_U or u_l3/10.0 < MIN_U: err_code = 2
        elif u_l1/10.0 > MAX_U or u_l2/10.0 > MAX_U or u_l3/10.0 > MAX_U: err_code = 3

        u_durchschnitt = (u_l1 + u_l2 + u_l3) / 30.0 if err_code != 4 else 0.0
        i_summe = (i_l1 + i_l2 + i_l3) / 1000.0

        if (time.time() - letzter_erfolgs_ts) <= WATCH_TIMEOUT_S:
            dbus['/Connected'] = 1
            dbus['/ErrorCode'] = err_code
            dbus['/Ac/Voltage'] = round(u_durchschnitt, 1) if u_durchschnitt > 0.0 else None
            dbus['/Ac/Power'] = int(p_tot)
            dbus['/Ac/Current'] = round(i_summe, 3)
            dbus['/Ac/ApparentPower'] = int(s_tot)
            dbus['/Ac/ReactivePower'] = int(q_tot)
            dbus['/Ac/PowerFactor'] = round(pf_tot, 3)

            dbus['/Ac/LineToLine/L1ToL2'] = round(u_l12/10.0, 1); dbus['/Ac/LineToLine/L2ToL3'] = round(u_l23/10.0, 1); dbus['/Ac/LineToLine/L3ToL1'] = round(u_l31/10.0, 1)
            dbus['/Ac/L1/Voltage'] = round(u_l1/10.0, 1); dbus['/Ac/L2/Voltage'] = round(u_l2/10.0, 1); dbus['/Ac/L3/Voltage'] = round(u_l3/10.0, 1)
            dbus['/Ac/L1/Current'] = round(i_l1/1000.0, 3); dbus['/Ac/L2/Current'] = round(i_l2/1000.0, 3); dbus['/Ac/L3/Current'] = round(i_l3/1000.0, 3)
            dbus['/Ac/L1/Power'] = int(p_l1); dbus['/Ac/L2/Power'] = int(p_l2); dbus['/Ac/L3/Power'] = int(p_l3)
            dbus['/Ac/L1/ReactivePower'] = int(q_l1); dbus['/Ac/L2/ReactivePower'] = int(q_l2); dbus['/Ac/L3/ReactivePower'] = int(q_l3)
            dbus['/Ac/L1/ApparentPower'] = int(s_l1); dbus['/Ac/L2/ApparentPower'] = int(s_l2); dbus['/Ac/L3/ApparentPower'] = int(s_l3)
            dbus['/Ac/L1/PowerFactor'] = round(pf_l1, 3); dbus['/Ac/L2/PowerFactor'] = round(pf_l2, 3); dbus['/Ac/L3/PowerFactor'] = round(pf_l3, 3)
            dbus['/Ac/L1/PhaseAngle'] = round(ang_l1, 1); dbus['/Ac/L2/PhaseAngle'] = round(ang_l2, 1); dbus['/Ac/L3/PhaseAngle'] = round(ang_l3, 1)
        else:
            dbus['/Connected'] = 1
            dbus['/ErrorCode'] = 4
            dbus['/Ac/Power'] = FB_TOT
            dbus['/Ac/L1/Power'] = FB_L1; dbus['/Ac/L2/Power'] = FB_L2; dbus['/Ac/L3/Power'] = FB_L3
            dbus['/Ac/Voltage'] = None; dbus['/Ac/Current'] = None; dbus['/Ac/ApparentPower'] = None
            dbus['/Ac/ReactivePower'] = None; dbus['/Ac/PowerFactor'] = None
            for p in ['L1', 'L2', 'L3']:
                dbus[f'/Ac/{p}/Voltage'] = None; dbus[f'/Ac/{p}/Current'] = None
                dbus[f'/Ac/{p}/ReactivePower'] = None; dbus[f'/Ac/{p}/ApparentPower'] = None
                dbus[f'/Ac/{p}/PowerFactor'] = None; dbus[f'/Ac/{p}/PhaseAngle'] = None


        if len(v2) >= 19:
            summen_zaehler = float(v2[0])
            real_export    = float(v2[15])
            real_export_l1 = float(v2[16])
            real_export_l2 = float(v2[17])
            real_export_l3 = float(v2[18])
            real_import    = summen_zaehler - real_export
            real_import_l1 = float(v2[1])
            real_import_l2 = float(v2[2])
            real_import_l3 = float(v2[3])

            if TAUSCH_E:
                dbus['/Ac/Energy/Forward'] = round(real_export, 2)
                dbus['/Ac/Energy/Reverse'] = round(real_import, 2)
            else:
                dbus['/Ac/Energy/Forward'] = round(real_import, 2)
                dbus['/Ac/Energy/Reverse'] = round(real_export, 2)

            if TAUSCH_P_E:
                dbus['/Ac/L1/Energy/Forward'] = round(real_export_l1, 2)
                dbus['/Ac/L2/Energy/Forward'] = round(real_export_l2, 2)
                dbus['/Ac/L3/Energy/Forward'] = round(real_export_l3, 2)
                dbus['/Ac/L1/Energy/Reverse'] = round(real_import_l1, 2)
                dbus['/Ac/L2/Energy/Reverse'] = round(real_import_l2, 2)
                dbus['/Ac/L3/Energy/Reverse'] = round(real_import_l3, 2)
            else:
                dbus['/Ac/L1/Energy/Forward'] = round(real_import_l1, 2)
                dbus['/Ac/L2/Energy/Forward'] = round(real_import_l2, 2)
                dbus['/Ac/L3/Energy/Forward'] = round(real_import_l3, 2)
                dbus['/Ac/L1/Energy/Reverse'] = round(real_export_l1, 2)
                dbus['/Ac/L2/Energy/Reverse'] = round(real_export_l2, 2)
                dbus['/Ac/L3/Energy/Reverse'] = round(real_export_l3, 2)

            raw_imp_q = float(v2[5])
            raw_exp_q = float(v2[10])

            if TAUSCH_E:
                dbus['/Ac/Energy/Reactive/Forward'] = round(raw_exp_q, 2)
                dbus['/Ac/Energy/Reactive/Reverse'] = round(raw_imp_q, 2)
            else:
                dbus['/Ac/Energy/Reactive/Forward'] = round(raw_imp_q, 2)
                dbus['/Ac/Energy/Reactive/Reverse'] = round(raw_exp_q, 2)
    return True

GLib.timeout_add(1000, dbus_vordergrund_schleife)
mainloop = GLib.MainLoop()
try: mainloop.run()
except KeyboardInterrupt: pass
finally:
    dbus['/Connected'] = 0
    if ser and ser.is_open: ser.close()
