# -*- coding: utf-8 -*-
# Copyright (c) 2026 Einstein-Project
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, version 3.
# by Klaus Reitbauer & google-gemini

# Modbus RTU Register-Matrix: Chint DTSU666-CT (Hoymiles-Edition)

Diese Dokumentation beschreibt das herstellerspezifische Register-Mapping der modifizierten Chint DTSU666-CT Firmware (Hoymiles-Edition). 

## Technische Spezifikationen & Datenformat
* **Protokoll:** Modbus RTU
* **Standard-Übertragungsrate:** 9600 Baud | 8 Databits | Keine Parität | 1 Stoppbit (n.1)
* **Standard-Modbus-ID:** Entspricht den letzten 3 Ziffern der Hoymiles DTU-Seriennummer.
* **Datentyp:** Alle Messwerte werden als **32-Bit Gleitkommazahl (Float)** übertragen.
* **Byte-Reihenfolge:** Standardmäßig **ABCD (Big-Endian)**.
* **Register-Länge:** Jedes Datenfeld belegt **2 Modbus-Register** (4 Bytes). Die Register-Adressen steigen daher in 2er-Schritten.

---

## 1. Momentanwerte: `0x2000` Datenblock (Lückenlos)

Dieser Block liefert die Echtzeitdaten des Netzes. Die Werte werden zyklisch (z.B. im 1000ms-Intervall) von der DTU abgefragt.

| Index | Start-Register (Hex) | Parameter-Bezeichnung | Interner Skalierungsfaktor | Einheit | Physikalische Bedeutung |
| :---: | :--- | :--- | :---: | :---: | :--- |
| **[00]** | `0x2000` | U_L1-L2 | / 10 | V | Außenleiterspannung Phase 1 zu Phase 2 |
| **[01]** | `0x2002` | U_L2-L3 | / 10 | V | Außenleiterspannung Phase 2 zu Phase 3 |
| **[02]** | `0x2004` | U_L3-L1 | / 10 | V | Außenleiterspannung Phase 3 zu Phase 1 |
| **[03]** | `0x2006` | UA (L1) | / 10 | V | Phasen-Spannung L1 gegen Neutralleiter (N) |
| **[04]** | `0x2008` | UB (L2) | / 10 | V | Phasen-Spannung L2 gegen Neutralleiter (N) |
| **[05]** | `0x200A` | UC (L3) | / 10 | V | Phasen-Spannung L3 gegen Neutralleiter (N) |
| **[06]** | `0x200C` | IA (L1) | / 1000 | A | Phasen-Stromstärke L1 |
| **[07]** | `0x200E` | IB (L2) | / 1000 | A | Phasen-Stromstärke L2 |
| **[08]** | `0x2010` | IC (L3) | / 1000 | A | Phasen-Stromstärke L3 |
| **[09]** | `0x2012` | Pt Gesamt | / 10 | W | **Gesamte Wirkleistung** (*Hinweis: Negativ = Bezug / Positiv = Einspeisung*) |
| **[10]** | `0x2014` | PA (L1) | / 10 | W | Wirkleistung Phase L1 |
| **[11]** | `0x2016` | PB (L2) | / 10 | W | Wirkleistung Phase L2 |
| **[12]** | `0x2018` | PC (L3) | / 10 | W | Wirkleistung Phase L3 |
| **[13]** | `0x201A` | Qt Gesamt | / 10 | var | **Gesamte Blindleistung** |
| **[14]** | `0x201C` | QA (L1) | / 10 | var | Blindleistung Phase L1 |
| **[15]** | `0x201E` | QB (L2) | / 10 | var | Blindleistung Phase L2 |
| **[16]** | `0x2020` | QC (L3) | / 10 | var | Blindleistung Phase L3 |
| **[17]** | `0x2022` | St Gesamt | / 10 | VA | **Gesamte Scheinleistung** |
| **[18]** | `0x2024` | SA (L1) | / 10 | VA | Scheinleistung Phase L1 |
| **[19]** | `0x2026` | SB (L2) | / 10 | VA | Scheinleistung Phase L2 |
| **[20]** | `0x2028` | SC (L3) | / 10 | VA | Scheinleistung Phase L3 |
| **[21]** | `0x202A` | PF Gesamt | / 1000 | - | **Gesamter Leistungsfaktor (Power Factor)** |
| **[22]** | `0x202C` | PF L1 | / 1000 | - | Leistungsfaktor Phase L1 |
| **[23]** | `0x202E` | PF L2 | / 1000 | - | Leistungsfaktor Phase L2 |
| **[24]** | `0x2030` | PF L3 | / 1000 | - | Leistungsfaktor Phase L3 |
| **[25]** | `0x2032` | Phasenwinkel L1 | / 10 | ° | Phasenverschiebungswinkel (Strom zu Spannung) Phase L1 |
| **[26]** | `0x2034` | Phasenwinkel L2 | / 10 | ° | Phasenverschiebungswinkel (Strom zu Spannung) Phase L2 |
| **[27]** | `0x2036` | Phasenwinkel L3 | / 10 | ° | Phasenverschiebungswinkel (Strom zu Spannung) Phase L3 |
| **[28]** | `0x2038` | Netzfrequenz | - | Hz | *Inaktiv (Wird von dieser Firmware dauerhaft mit 0.00 ausgegeben)* |
| **[29]** | `0x203A` | Drehrichtung | - | Code | Drehfeld-Erkennung (`0` = Rechtsdrehfeld / `1` = Linksdrehfeld) |
| **[30]** | `0x203C` | Padding | - | - | Reserviertes End-Register (Null-Rahmen zur Paketabrundung) |

---

## 2. Zählerstände: `0x4000` Energie-Pfad (Lückenlos)

In diesem Block werden die akkumulierten Energiemengen erfasst. Durch die Firmware-Modifikation sind die Standard-Import-Register verschoben oder umgewidmet.

| Index | Start-Register (Hex) | Parameter-Bezeichnung | Einheit | Physikalische Bedeutung (Hoymiles-Zuweisung) |
| :---: | :--- | :--- | :---: | :--- |
| **[00]** | `0x4000` | Absolute Wirkenergie | kWh | **Absoluter Gesamtzählerstand** (Summe aus partiellem Import + Export) |
| **[01]** | `0x4002` | - | kWh | *Umgemappt / Deaktiviert durch Firmware (Liefert 0.00)* |
| **[02]** | `0x4004` | - | kWh | *Umgemappt / Deaktiviert durch Firmware (Liefert 0.00)* |
| **[03]** | `0x4006` | - | kWh | *Umgemappt / Deaktiviert durch Firmware (Liefert 0.00)* |
| **[04]** | `0x4008` | - | kWh | *Umgemappt / Deaktiviert durch Firmware (Liefert 0.00)* |
| **[05]** | `0x400A` | Reactive Energy (+) | kvarh | **Positive Blindenergie Gesamt** (Induktive Arbeit aus dem Netz) |
| **[06]** | `0x400C` | - | kvarh | *Ungenutzter Platzhalter / Leerwert (Liefert 0.00)* |
| **[07]** | `0x400E` | - | kvarh | *Ungenutzter Platzhalter / Leerwert (Liefert 0.00)* |
| **[08]** | `0x4010` | - | kvarh | *Ungenutzter Platzhalter / Leerwert (Liefert 0.00)* |
| **[09]** | `0x4012` | - | kvarh | *Ungenutzter Platzhalter / Leerwert (Liefert 0.00)* |
| **[10]** | `0x4014` | Reactive Energy (-) | kvarh | **Negative Blindenergie Gesamt** (Kapazitive Arbeit ins Netz rückgespeist) |
| **[11]** | `0x4016` | - | kvarh | *Ungenutzter Platzhalter / Leerwert (Liefert 0.00)* |
| **[12]** | `0x4018` | - | kvarh | *Ungenutzter Platzhalter / Leerwert (Liefert 0.00)* |
| **[13]** | `0x401A` | - | kvarh | *Ungenutzter Platzhalter / Leerwert (Liefert 0.00)* |
| **[14]** | `0x401C` | - | kWh | *Reserviert für erweiterte Phasen-Energie-Statistiken* |
| **[15]** | `0x401E` | Active Import Gesamt | kWh | **Wirkenergie Netzbezug (Import) Gesamt** (Entspricht dem Display-Hauptwert) |
| **[16]** | `0x4020` | Active Import L1 | kWh | Wirkenergie Netzbezug (Import) auf Phase L1 |
| **[17]** | `0x4022` | Active Import L2 | kWh | Wirkenergie Netzbezug (Import) auf Phase L2 |
| **[18]** | `0x4024` | Active Import L3 | kWh | Wirkenergie Netzbezug (Import) auf Phase L3 |

### 💡 Wichtiger Berechnungshinweis für den Gesamtexport (Einspeisung)
Die Firmware spiegelt den kumulierten **Gesamt-Export (Netzeinspeisung)** nicht auf ein dediziertes Einzelregister. Da Register `0x4000` die absolute Gesamtarbeit und `0x401E` den reinen Import liefert, lässt sich der reale Gesamtexport im auswertenden System jederzeit exakt per Software errechnen:

\[\text{Wirkenergie Export Gesamt} = \text{Absolute Wirkenergie (0x4000)} - \text{Active Import Gesamt (0x401E)}\]
