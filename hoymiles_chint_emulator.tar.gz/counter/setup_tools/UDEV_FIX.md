# -*- coding: utf-8 -*-
# Copyright (c) 2026 Einstein-Project
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, version 3.
# by Klaus Reitbauer & google-gemini



# Victron udev-Sperre gegen Timeout-Probleme (vedirect-dbus)

## Das Problem
Venus OS scannt im Hintergrund permanent alle USB-Schnittstellen nach eigenen Geräten ab (`vedirect-interface`). Dieser Dienst grätscht asynchron in den Modbus-Datenstrom unseres Emulators und stiehlt serielle Byte-Pakete auf Kernel-Ebene. Die Folge sind unregelmäßige "0 Bytes Dauer-Timeouts" im Log des Emulators.

## Die Lösung
Eine persistente, updatesichere udev-Regel im geschützten `/data/`-Verzeichnis schließt das verwendete Kabel exklusiv vom automatischen Victron-Scanning aus.

### Schritt 1: Verzeichnis für udev-Regeln erstellen
Sollte der udev-Konfigurationsordner im beschreibbaren Victron-Verzeichnis noch nicht existieren, lege ihn an:
```bash
mkdir -p /data/conf/udev/rules.d
```

### Schritt 2: udev-Regel anlegen
Erstelle eine neue Regeldatei (z.B. `99-chint-override.rules`). 
*Hinweis: Wenn du das Hilfsprogramm `ftdi_finder.py` ausgeführt hast, kannst du deine exakte Seriennummer aus der `counter.ini` ablesen und hier einsetzen (Ersetze `DEINE_SERIENNUMMER`).*

```text
# RS485-Wandler für den Chint-Zähler vom automatischen Victron-Scanning ausschließen
SUBSYSTEM=="tty", ATTRS{idVendor}=="0403", ATTRS{idProduct}=="6001", ATTRS{serial}=="DEINE_SERIENNUMMER", ENV{VE_IGNORE}="1"
```

### Schritt 3: udev-Regeln neu laden und triggern
Damit das Betriebssystem die Regel sofort übernimmt, führe diese Befehle aus:
```bash
udevadm control --reload-rules && udevadm trigger
```

### Schritt 4: Blockierenden Victron-Prozess einmalig beenden
Prüfe auf deiner Konsole, ob noch ein Prozess die Leitung blockiert (z. B. via `by-id`-Pfad):
```bash
PID=$(fuser /dev/serial/by-id/usb-FTDI_FT232R_USB_UART_DEINE_SERIENNUMMER-if00-port0 2>/dev/null); [ ! -z "$PID" ] && ps | grep "$PID" || echo "Schnittstelle ist absolut frei!"
```

Falls dort eine Prozess-ID (PID) von `vedirect-dbus` auftaucht, wirf den Blockierer hart aus dem RAM:
```bash
fuser -k /dev/serial/by-id/usb-FTDI_FT232R_USB_UART_DEINE_SERIENNUMMER-if00-port0
```
Danach gehört die Schnittstelle dem Emulator dauerhaft und exklusiv.
