#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ===============================================================================
# Copyright (c) 2026 Einstein-Project
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, version 3.
# ===============================================================================

import configparser
import os
import glob
import sys
import serial.tools.list_ports
import subprocess

def frage_user(frage_text):
    while True:
        antwort = input(f"{frage_text} (Ja/Nein oder j/n): ").strip().lower()
        if antwort in ['j', 'ja']: return True
        if antwort in ['n', 'nein']: return False
        print("[!] Bitte mit 'Ja/j' oder 'Nein/n' antworten.")

def main():
    os.system('clear')
    print("==================================================")
    print("📊 CHINT-HOYMILES EMULATOR - SCHRITT 2: KABEL-FINDER")
    print("==================================================")
    
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    ini_file = os.path.join(base_dir, 'counter.ini')
    
    # Hartes Sicherheitsnetz für fehlende counter.ini
    if not os.path.exists(ini_file):
        print("\n[🚨] KRITISCHER FEHLER: 'counter.ini' existiert nicht!")
        print(f"    Der Emulator-Hauptordner ist unvollständig.")
        print(f"    Bitte installiere die originale 'counter.ini' nach unter:")
        print(f"    {ini_file}")
        print("    Abbruch.\n")
        sys.exit(1)

    all_ports = serial.tools.list_ports.comports()
    usb_ports = [p for p in all_ports if "USB" in p.description.upper() or "UART" in p.description.upper()]
            
    if not usb_ports:
        print("[!] FEHLER: Kein unterstütztes USB-RS485-Kabel am System gefunden.")
        sys.exit(1)
        
    print("\n=== VERFÜGBARE USB-WANDLER AM SYSTEM ===")
    for i, p in enumerate(usb_ports):
        sn = p.serial_number if p.serial_number else "KEINE SERIENNUMMER"
        print(f"[{i}] Port: {p.device} | Beschreibung: {p.description} | SN: {sn}")
    print("=========================================\n")
    
    try:
        choice = input("Wähle die Nummer deines Chint-Kabels (z.B. 0): ")
        selected_port = usb_ports[int(choice)]
    except (ValueError, IndexError):
        print("[!] Ungültige Auswahl! Vorgang abgebrochen.")
        sys.exit(1)
        
    serial_number = selected_port.serial_number if selected_port.serial_number else "UNBEKANNT"
    
    by_id_path = ""
    available_by_id_files = glob.glob("/dev/serial/by-id/*")
    for path in available_by_id_files:
        if serial_number != "UNBEKANNT" and serial_number in path:
            by_id_path = path
            break
            
    if not by_id_path:
        if available_by_id_files and len(usb_ports) == 1:
            by_id_path = available_by_id_files
        else:
            by_id_path = selected_port.device
            print("[!] Warnung: Konnte keinen eindeutigen '/dev/serial/by-id/' Pfad matchen.")

    config = configparser.ConfigParser()
    config.optionxform = str
    config.read(ini_file)
    
    if not config.has_section('Schnittstelle'):
        config.add_section('Schnittstelle')
        
    config.set('Schnittstelle', 'hardware_id', by_id_path)
    config.set('Schnittstelle', 'kabel_serial', serial_number)
    
    with open(ini_file, 'w') as configfile:
        config.write(configfile)
        
    os.system('clear')
    GRUEN = "\033[92m"
    GELB = "\033[93m"
    RESET = "\033[0m"

    print("--------------------------------------------------")
    print(f"{GRUEN}[🎉] Konfiguration erfolgreich in 'counter.ini' eingetragen!{RESET}")
    print("==================================================")
    
    if serial_number != "UNBEKANNT":
        print(f"\n[💡] {GELB}MAẞGESCHNEIDERTER UDEV-BEFEHL FÜR DIESES KABEL:{RESET}")
        print("-------------------------------------------------------------------------")
        print(GELB, end="")
        print("mkdir -p /data/conf/udev/rules.d")
        print("cat << 'UDEV_EOF' > /data/conf/udev/rules.d/99-chint-override.rules")
        print("# FTDI-Wandler fuer den Chint-Zaehler vom automatischen Victron-Scanning ausschliessen")
        print(f'SUBSYSTEM=="tty", ATTRS{{idVendor}}=="0403", ATTRS{{idProduct}}=="6001", ATTRS{{serial}}==\"{serial_number}\", ENV{{VE_IGNORE}}="1", ENV{{ID_MM_DEVICE_IGNORE}}="1", ENV{{ID_RESERVED_FROM_AUTO_RECONITION}}="1"')
        print(f'SUBSYSTEM=="tty", ATTRS{{idVendor}}=="0403", ATTRS{{idProduct}}=="6001", ATTRS{{serial}}==\"{serial_number}\", OWNER="root", GROUP="root", MODE="0600"')
        print("UDEV_EOF")
        print("udevadm control --reload-rules && udevadm trigger")
        print(RESET, end="")
        print("-------------------------------------------------------------------------")
        
        if frage_user("\n[?] Soll das Setup diese udev-Sperre jetzt automatisch für dich im System einrichten?"):
            try:
                os.makedirs("/data/conf/udev/rules.d", exist_ok=True)
                rule_text = f'# FTDI-Wandler fuer den Chint-Zaehler vom automatischen Victron-Scanning ausschliessen\nSUBSYSTEM=="tty", ATTRS{{idVendor}}=="0403", ATTRS{{idProduct}}=="6001", ATTRS{{serial}}=="{serial_number}", ENV{{VE_IGNORE}}="1", ENV{{ID_MM_DEVICE_IGNORE}}="1", ENV{{ID_RESERVED_FROM_AUTO_RECONITION}}="1"\nSUBSYSTEM=="tty", ATTRS{{idVendor}}=="0403", ATTRS{{idProduct}}=="6001", ATTRS{{serial}}="{serial_number}", OWNER="root", GROUP="root", MODE="0600"\n'
                with open("/data/conf/udev/rules.d/99-chint-override.rules", "w") as uf:
                    uf.write(rule_text)
                subprocess.run(["udevadm", "control", "--reload-rules"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                subprocess.run(["udevadm", "trigger"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                print(f"{GRUEN}[✓] udev-Sperre erfolgreich im Hintergrund aktiv geschaltet!{RESET}")
            except Exception as e:
                print(f"[!] Fehler beim automatischen udev-Fix: {e}")
        
    print("--------------------------------------------------")
    print("[➔] SCHRITT 2 BEENDET.")
    if frage_user("[?] Möchtest du JETZT den Daemontools-Hintergrundservice (Schritt 3) einrichten und zünden?"):
        script_dir = os.path.dirname(os.path.abspath(__file__))
        subprocess.run([sys.executable, os.path.join(script_dir, "service_installer.py")])
    else:
        print("\n    Hinweis zum manuellen Start von Schritt 3:")
        print("    python3 /data/etc/victron-device-emulators/02_device_emulators/counter/setup_tools/service_installer.py")
    print("==================================================")

if __name__ == "__main__":
    main()
