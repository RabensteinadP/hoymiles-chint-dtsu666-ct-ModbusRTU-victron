#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ===============================================================================
# Copyright (c) 2026 Einstein-Project
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, version 3.
# ===============================================================================
# 🎯 URHEBER-HINWEIS & PROJEKT-HISTORIE:
# Alle Erkenntnisse und auch der Code wurden durch eine enge Zusammenarbeit von
# Klaus Reitbauer und Google-Gemini ausgearbeitet.
# ===============================================================================

import os
import sys
import time
import subprocess

def frage_user(frage_text):
    while True:
        antwort = input(f"{frage_text} (Ja/Nein oder j/n): ").strip().lower()
        if antwort in ['j', 'ja']: return True
        if antwort in ['n', 'nein']: return False
        print("[!] Bitte mit 'Ja/j' oder 'Nein/n' antworten.")

def get_service_pid(service_link):
    """Ermittelt die aktuelle PID des Daemontools-Dienstes via svstat"""
    try:
        res = subprocess.run(["svstat", service_link], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out = res.stdout.strip()
        if "pid" in out:
            parts = out.split("pid ")
            if len(parts) > 1:
                pid = parts[1].split(")")[0].strip()
                return pid
    except:
        pass
    return None

def main():
    os.system('clear')
    print("==================================================")
    print("📊 CHINT-EMULATOR - SCHRITT 3: DAEMON INTEGRATION")
    print("==================================================")
    
    service_dir = "/data/service/chint-counter"
    service_link = "/service/chint-counter"
    run_file_path = os.path.join(service_dir, "run")
    
    print("[⚙️] DAEMONTOOLS INTEGRATION NACH SYSTEMDOKTRINE:")
    print(f"    • Ziel-Verzeichnis: {service_dir}")
    print(f"    • System-Symlink:   {service_link}")
    
    if not frage_user("\n[?] Möchtest du den Daemontools-Hintergrunddienst jetzt live aktivieren?"):
        print("[!] Vorgang abgebrochen. Der Dienst wurde nicht eingerichtet."); sys.exit(0)

    try:
        # 1. Dienstverzeichnis physisch anlegen (falls nicht vorhanden)
        os.makedirs(service_dir, exist_ok=True)
        
        # 2. Die originale run-Datei NUR schreiben, wenn sie noch nicht existiert!
        if not os.path.exists(run_file_path):
            run_content = """#!/bin/sh
exec 2>&1
echo "🚀 Starte CHINT DTSU666 Modbus-dbus Emulator..."
exec /data/etc/victron-device-emulators/02_device_emulators/counter/chint_dbus_emu.py
"""
            with open(run_file_path, "w") as rf:
                rf.write(run_content)
            os.chmod(run_file_path, 0o755)
            print("[✓] Physisches Dienst-Skript erfolgreich neu geschrieben (chmod 755).")
        else:
            print("[✓] Eine bestehende 'run'-Datei wurde erkannt. Schutzregel aktiv: Datei bleibt UNBERÜHRT.")
        
        # 3. Prüfen und Setzen des Symlinks
        if not os.path.islink(service_link):
            os.symlink(service_dir, service_link)
            print(f"[✓] Symlink im System-Diensteverzeichnis angelegt: {service_link}")
        else:
            print("[✓] Symlink existiert bereits im System.")

        # 4. Den Dienst live im RAM zünden mit deiner exakten Timing-Doktrine
        print("[⚡] Aktiviere Hintergrunddienst (svc -u)...")
        subprocess.run(["svc", "-u", service_link], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        
        print("[⏳] Warte 2 Sekunden auf Prozess-Initialisierung...")
        time.sleep(2.0)
        
        print("[🔄] Erzwinge frische eMMC-Einlesung via Stoßtritt (svc -t)...")
        subprocess.run(["svc", "-t", service_link], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        
        print("[⏳] Warte 2 Sekunden auf Stabilisierung des neuen Datei-Handles...")
        time.sleep(2.0)

        # 5. AUTOMATISIERTE PID-WÄCHTER-SCHLEIFE (3-fach Prüfung im 2s Takt)
        print("\n[🔍] STARTE AUTOMATISIERTE FORENSISCHE PROZESS-VALIDIERUNG:")
        print("-------------------------------------------------------------------------")
        
        pids = []
        fehler_erkannt = False
        
        for check in range(1, 4):
            current_pid = get_service_pid(service_link)
            if current_pid:
                pids.append(current_pid)
                print(f"    -> Prüfung #{check}: Dienst läuft stabil auf Prozess-ID (PID): {current_pid}")
            else:
                pids.append("FAIL")
                print(f"    -> Prüfung #{check}: ❌ KEINE PID ERMITTELBAR! Der Dienst schläft.")
                fehler_erkannt = True
            
            if check < 3:
                time.sleep(2.0)

        print("-------------------------------------------------------------------------")

        # 6. Automatische Auswertung und Notbremse
        # Wenn sich die PIDs unterscheiden (Länge des 'set' ist > 1) oder ein FAIL dabei war
        if not fehler_erkannt and len(set(pids)) == 1:
            print(f"\n[🎉] Hintergrundprozess läuft stabil! Die PID {pids[0]} ist absolut stabil.")
            print("     Der Chint-Emulator läuft ab jetzt autark und updatesicher im Hintergrund.")
        else:
            print("\n[🚨] KRITISCHER FEHLER: Unstabiles Prozessverhalten erkannt!")
            print(f"    Ermittelte PID-Kette der Testreihe: {pids}")
            print("    Das Hauptskript stürzt im Sekundentakt ab (Crash-Loop).")
            print(f"    ➔ [NOTBREMSE] Setze Dienst automatisiert auf DEAKTIVIERT (svc -d)...")
            
            # Automatische Notbremse feuern
            subprocess.run(["svc", "-d", service_link], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            print("\n[💡] URSACHEN-DIAGNOSE:")
            print("    Der Dienst wurde gestoppt, um dein System zu schützen.")
            print("    Mögliche Gründe: Schnittstelle blockiert, falsche Modbus-ID,")
            print("    oder fehlende Python-Bibliotheken im Venus OS.")
            print("    Bitte prüfe alles nochmal oder starte das Hauptskript manuell,")
            print("    um den genauen Fehler aufzudecken.   ")
            print(" python3 /data/etc/victron-device-emulators/02_device_emulators/counter/chint_dbus_emu.py") 
        print("==================================================")

    except Exception as e:
        print(f"[!] SCHWERWIEGENDER FEHLER bei der Dienst-Installation: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
