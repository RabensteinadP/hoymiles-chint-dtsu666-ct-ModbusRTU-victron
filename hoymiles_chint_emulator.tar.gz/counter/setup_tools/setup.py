#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ===============================================================================
# Copyright (c) 2026 Einstein-Project
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, version 3.
# ===============================================================================

import os
import sys
import configparser
import subprocess

def frage_user(frage_text):
    while True:
        antwort = input(f"{frage_text} (Ja/Nein oder j/n): ").strip().lower()
        if antwort in ['j', 'ja']: return True
        if antwort in ['n', 'nein']: return False
        print("[!] Bitte mit 'Ja/j' oder 'Nein/n' antworten.")

def main():
    os.system('clear')
    print("==================================================")
    print("📊 CHINT-EMULATOR - SCHRITT 1: FRAMEWORK & BOOT SETUP")
    print("==================================================")
    
    config_dir = "/data/etc/victron-device-emulators/config"
    pfade_ini_path = os.path.join(config_dir, "pfade.ini")
    rc_local_path = "/data/rc.local"
    rcs_local_path = "/data/rcS.local"
    section_name = "CHINT_EMULATOR_PATHS"
    
    if not os.path.exists(config_dir):
        print(f"[!] HINWEIS: Das Framework-Verzeichnis '{config_dir}' existiert noch nicht.")
        if frage_user("[?] Möchtest du, dass dieses Setup den Ordner anlegt?"):
            os.makedirs(config_dir, exist_ok=True)
        else:
            print("[!] Abbruch."); sys.exit(1)

    config = configparser.ConfigParser()
    config.optionxform = str
    
    if os.path.exists(pfade_ini_path):
        config.read(pfade_ini_path)
    else:
        print(f"[!] HINWEIS: Die zentrale 'pfade.ini' existiert noch nicht.")
        if not frage_user("[?] Möchtest du eine neue 'pfade.ini' anlegen?"):
            print("[!] Abbruch."); sys.exit(1)

    dirty = False
    if not config.has_section(section_name):
        config.add_section(section_name)
        dirty = True
        
    expected_ini = "/data/etc/victron-device-emulators/02_device_emulators/counter/counter.ini"
    expected_script = "/data/etc/victron-device-emulators/02_device_emulators/counter/chint_dbus_emu.py"
    
    if config.get(section_name, 'counter_ini_path', fallback=None) != expected_ini:
        config.set(section_name, 'counter_ini_path', expected_ini); dirty = True
    if config.get(section_name, 'counter_script_path', fallback=None) != expected_script:
        config.set(section_name, 'counter_script_path', expected_script); dirty = True

    if dirty:
        with open(pfade_ini_path, 'w') as f: config.write(f)
        print("[✓] 'pfade.ini' erfolgreich konfiguriert und validiert.")
    else:
        print("[✓] 'pfade.ini' bereits perfekt im Framework integriert.")

    print("--------------------------------------------------")

    # 2. rcS.local
    rcs_schreiben = True
    if os.path.exists(rcs_local_path):
        with open(rcs_local_path, 'r') as f:
            if "/data/rc.local &" in f.read():
                rcs_schreiben = False
                print("[✓] 'rcS.local' ist bereits vorhanden und korrekt verknüpft.")

    if rcs_schreiben:
        if frage_user("[?] Möchtest du die updatesichere 'rcS.local' einrichten?"):
            with open(rcs_local_path, 'w') as f:
                f.write("#!/bin/sh\n/data/rc.local &\n")
            os.chmod(rcs_local_path, 0o755)
            print("[✓] 'rcS.local' erfolgreich mit chmod 755 geschrieben.")

    print("--------------------------------------------------")

    # 3. rc.local
    if os.path.exists(rc_local_path):
        with open(rc_local_path, 'r') as f: rc_content = f.read()
    else:
        rc_content = "#!/bin/sh\nexit 0\n"

    if "CHINT NETZ-SMARTMETER" in rc_content:
        print("[✓] Der Chint-Emulator ist bereits in deiner 'rc.local' verankert.")
    else:
        if frage_user("[?] Möchtest du den Chint-Emulator in den Autostart (rc.local) aufnehmen?"):
            initial_sleep = ""
            if "sleep 10" not in rc_content:
                if frage_user("[?] Soll zu Beginn der rc.local ein 'sleep 10' für stabiles Booten eingefügt werden?"):
                    initial_sleep = "\nsleep 10\n"
            
            chint_block = f"""
# CHINT NETZ-SMARTMETER (com.victronenergy.grid.gw40) - DAEMONTOOLS INTEGRATION
if [ ! -L /service/chint-counter ] && [ -d /data/service/chint-counter ]; then
    ln -s /data/service/chint-counter /service/chint-counter
fi
chmod 755 /data/service/chint-counter/run 2>/dev/null
svc -u /service/chint-counter
sleep 2
"""
            if "exit 0" in rc_content:
                parts = rc_content.rsplit("exit 0", 1)
                new_content = parts[0] + initial_sleep + chint_block + "\nexit 0" + parts[1]
            else:
                new_content = rc_content + initial_sleep + chint_block

            with open(rc_local_path, 'w') as f: f.write(new_content)
            os.chmod(rc_local_path, 0o755)
            print("[✓] Autostart-Block erfolgreich in 'rc.local' integriert (chmod 755).")

    print("--------------------------------------------------")
    print("[➔] SCHRITT 1 BEENDET.")
    if frage_user("[?] Möchtest du JETZT direkt mit Schritt 2 (Kabel-Finder) fortfahren?"):
        script_dir = os.path.dirname(os.path.abspath(__file__))
        subprocess.run([sys.executable, os.path.join(script_dir, "ftdi_finder.py")])
    else:
        print("\n    Hinweis zum manuellen Start von Schritt 2:")
        print("    python3 /data/etc/victron-device-emulators/02_device_emulators/counter/setup_tools/ftdi_finder.py")
    print("==================================================")

if __name__ == "__main__":
    main()
